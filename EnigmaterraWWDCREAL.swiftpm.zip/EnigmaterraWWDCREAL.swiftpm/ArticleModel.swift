//
//  ArticleModel.swift
//  EnigmaterraWWDCREAL
//
//  Created by Aktiv on 2/25/24.
//

import Foundation

enum Article: Hashable {
    case title(String)
    case text(String)
    case image(String)
    case logo(String)
}
