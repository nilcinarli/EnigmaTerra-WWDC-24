import SwiftUI

@available(iOS 17.0, *)
struct ContentView: View {
    @State private var shownTutorialView: Bool = false
    @State private var shownGameView: Bool = false
    var body: some View {
        ZStack {
                
            Image("enigmaterrabackground")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: UIScreen.main
                    .bounds.width)
                .edgesIgnoringSafeArea(.vertical)
                    
                    VStack(spacing: 30) {
                        Image("articleImage")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 200, height: 200)
                            .padding(.top, 100)
                    
                        
                        Button(action: {
                            shownGameView = true
                        }) {
                            Text("Start")
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding()
                                .frame(width: 200)
                                .background(Rectangle().fill(Color.blue))
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                                
                        }
                        
                        Button(action: {
                            shownTutorialView = true
                        }) {
                            Text("How to Play ?")
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding()
                                .frame(width: 200)
                                .background(Rectangle().fill(Color.blue))
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                        }
                        
                    }
                    
                }
        .frame(width: UIScreen.main.bounds.width)
        .fullScreenCover(isPresented: $shownTutorialView, content: {
            TutorialView()
        })
        .fullScreenCover(isPresented: $shownGameView, content: {
            GameView()
        })
    }
}
