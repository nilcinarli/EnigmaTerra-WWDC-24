//
//  GameInputView.swift
//  EnigmaterraWWDCREAL
//
//  Created by Aktiv on 2/25/24.
//

import SwiftUI

@available(iOS 17.0, *)
struct GameInputView: View {
    @Binding var levelPuzzle: PuzzleLevel
    @State var number: String = ""
    @State private var answerType: AnswerType = .none
    @Binding var isShownAnswer: Bool
    @Binding var restartGame: Bool
    @Binding var levelStatus: LevelStatus
    var body: some View {
        Rectangle()
            .stroke(Color(uiColor: .label))
            .overlay(TextField("?", text: $number).multilineTextAlignment(.center))
            .background(answerType != .none ? Color(answerType.rawValue) : Color.clear)
            .frame(width: 50, height: 50)
//            .onChange(of: number, <#T##action: (Equatable, Equatable) -> Void##(Equatable, Equatable) -> Void##(_ oldValue: Equatable, _ newValue: Equatable) -> Void#>)
//            .onChange(of: number, {
//                levelPuzzle.currentValue = number
//            })
//            .onChange(of: number, perform: { value in
//                l
//            })
            .onChange(of: number, { _, _ in
                levelPuzzle.currentValue = number
            })
            .onChange(of: isShownAnswer, {
                if isShownAnswer {
                    if levelPuzzle.value == Int(number) {
                        answerType = .correct
                        if levelStatus == .waiting {
                            levelStatus = .next
                        }
                    } else {
                        answerType = .wrong
                        levelStatus = .willreset
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            restartGame = true
                        }
                    }
                }
            })
            .onChange(of: restartGame, {
                if restartGame {
                    answerType = .none
                    number = ""
                    levelStatus = .waiting
                    isShownAnswer = false
                }
            })
    }
}

enum AnswerType: String {
    case none
    case correct
    case wrong
}

enum LevelStatus: String {
    case willreset
    case next
    case waiting
}
