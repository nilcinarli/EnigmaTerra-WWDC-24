//
//  TutorialView.swift
//  EnigmaterraWWDCREAL
//
//  Created by Aktiv on 2/25/24.
//

import SwiftUI

struct TutorialView: View {
    @Environment(\.dismiss) var dismiss
    @State private var selection: Int = 0
    private var tutorialView: [AnyView] = [
        AnyView(TutorialFirstView()),
        AnyView(TutorialSecondView()),
        AnyView(TutorialThirdView())
    ]
    var body: some View {
                    ZStack {
                        Image("enigmaterrabackground")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: UIScreen.main
                                .bounds.width)
                            .edgesIgnoringSafeArea(.vertical)
                        
                       
                        
                        VStack {
                            TabView(selection: $selection) {
                                ForEach(tutorialView.indices, id: \.self) { index in
                                    tutorialView[index]
                                        .tag(index)
                                        .foregroundColor(.white)
                                }
                                    
                            }
                            .tabViewStyle(.page(indexDisplayMode: .never))
                            .animation(.easeInOut, value: selection)
                            
                            HStack {
                                Button(action: {
                                    if selection > 0 {
                                        selection -= 1
                                    }
                                }, label: {
                                    if selection == 0 {
                                        EmptyView()
                                    } else {
                                        Text("Previous")
                                    }
                                })
                                Spacer()
                                Button(action: {
                                    if selection < tutorialView.count - 1{
                                        selection += 1
                                    }
                                }, label: {
                                    if selection == tutorialView.count - 1 {
                                        EmptyView()
                                    } else {
                                        Text("Next")
                                    }
                                    
                                })
                            }
                            .padding([.bottom, .horizontal], 32)
                        }
                        
                        HStack {
                            Spacer()
                            VStack {
                                Button {
                                    dismiss()
                                } label: {
                                    Image(systemName: "xmark.circle.fill")
                                        .imageScale(.large)
                                }
                                .padding()
                                Spacer()
                            }
                        }
                        
                    }
    }
}
