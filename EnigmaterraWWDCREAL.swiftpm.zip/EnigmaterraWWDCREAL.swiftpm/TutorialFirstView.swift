//
//  TutorialFirstView.swift
//  EnigmaterraWWDCREAL
//
//  Created by Aktiv on 2/25/24.
//

import SwiftUI

struct TutorialFirstView: View {
    let tutorialDataProvider = TutorialDataProvider()
    var body: some View {
        ScrollView(showsIndicators: false) {
            ForEach(tutorialDataProvider.getFirstTutorialViewArticle(), id: \.self) { article in
                switch article {
                case .title(let title):
                    Text(title)
                        .font(.title)
                case .text(let text):
                    Text(text)
                case .logo(let logo):
                    Image(logo)
                        .resizable()
                        .frame(width: 140, height: 120)
                        .aspectRatio(contentMode: .fit)
                case .image(let image):
                    Image(image)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(8)
                }
            }
        }
        .padding(.horizontal, 16)
    }
}


#Preview {
    TutorialFirstView()
}
