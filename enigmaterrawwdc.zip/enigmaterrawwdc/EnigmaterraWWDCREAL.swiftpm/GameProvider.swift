//
//  GameProvider.swift
//  EnigmaterraWWDCREAL
//
//  Created by Aktiv on 2/25/24.
//

import Foundation

final class GameProvider: ObservableObject {
    @Published var level: Level = Level(puzzle: [])
    
    func generateLevel() {
        let puzzle1 = Puzzle(
            puzzleLevel: [
                [PuzzleLevel(value: 2), PuzzleLevel(value: 1), PuzzleLevel(value: 3)],
                [PuzzleLevel(value: 1), PuzzleLevel(value: 3), PuzzleLevel(value: 2)],
                [PuzzleLevel(value: 3), PuzzleLevel(value: 2), PuzzleLevel(value: 1)]
            ],
            top: [0,2,2,1,0],
            bottom: [0,1,2,3,0],
            left: [0,2,2,1,0],
            right: [0,1,2,3,0])
        
        let puzzle2 = Puzzle(
            puzzleLevel: [
                [PuzzleLevel(value: 1), PuzzleLevel(value: 2), PuzzleLevel(value: 3)],
                [PuzzleLevel(value: 3), PuzzleLevel(value: 1), PuzzleLevel(value: 2)],
                [PuzzleLevel(value: 2), PuzzleLevel(value: 3), PuzzleLevel(value: 1)]
            ],
            top: [0,0,0,0,0],
            bottom: [0,0,0,3,0],
            left: [0,0,1,0,0],
            right: [0,0,0,0,0])
        
        let puzzle3 = Puzzle(
            puzzleLevel: [
                [PuzzleLevel(value: 4), PuzzleLevel(value: 3), PuzzleLevel(value: 2), PuzzleLevel(value: 1)],
                [PuzzleLevel(value: 3), PuzzleLevel(value: 2), PuzzleLevel(value: 1), PuzzleLevel(value: 4)],
                [PuzzleLevel(value: 2), PuzzleLevel(value: 1), PuzzleLevel(value: 4), PuzzleLevel(value: 3)],
                [PuzzleLevel(value: 1), PuzzleLevel(value: 4), PuzzleLevel(value: 3), PuzzleLevel(value: 2)]
            ],
            top: [0,0,0,0,0,0],
            bottom: [0,4,1,0,0,0],
            left: [0,0,0,0,0,0],
            right: [0,4,0,0,0,0])
        
        let puzzle4 = Puzzle(
            puzzleLevel: [
                [PuzzleLevel(value: 1), PuzzleLevel(value: 4), PuzzleLevel(value: 2), PuzzleLevel(value: 3),],
                [PuzzleLevel(value: 2), PuzzleLevel(value: 3), PuzzleLevel(value: 4), PuzzleLevel(value: 1),],
                [PuzzleLevel(value: 3), PuzzleLevel(value: 2), PuzzleLevel(value: 1), PuzzleLevel(value: 4),],
                [PuzzleLevel(value: 4), PuzzleLevel(value: 1), PuzzleLevel(value: 3), PuzzleLevel(value: 2),]
            ],
            top: [0,4,1,2,2,0,],
            bottom: [0,2,2,1,3,0],
            left: [0,2,3,2,1,0],
            right: [0,4,0,2,2,0])
        
        let puzzle5 = Puzzle(
            puzzleLevel: [
                [PuzzleLevel(value: 1), PuzzleLevel(value: 2), PuzzleLevel(value: 3), PuzzleLevel(value: 4),],
                [PuzzleLevel(value: 2), PuzzleLevel(value: 3), PuzzleLevel(value: 4), PuzzleLevel(value: 1),],
                [PuzzleLevel(value: 4), PuzzleLevel(value: 1), PuzzleLevel(value: 2), PuzzleLevel(value: 3),],
                [PuzzleLevel(value: 3), PuzzleLevel(value: 4), PuzzleLevel(value: 1), PuzzleLevel(value: 2),]
            ],
            top: [0,3,3,2,1,0,],
            bottom: [0,2,1,3,3,0],
            left: [0,4,3,1,2,0],
            right: [0,1,2,2,2,0])
        
        let puzzle6 = Puzzle(
            puzzleLevel: [
                [PuzzleLevel(value: 1), PuzzleLevel(value: 2), PuzzleLevel(value: 5), PuzzleLevel(value: 4),PuzzleLevel(value: 3)],
                [PuzzleLevel(value: 2), PuzzleLevel(value: 3), PuzzleLevel(value: 4), PuzzleLevel(value: 1),PuzzleLevel(value: 5)],
                [PuzzleLevel(value: 3), PuzzleLevel(value: 5), PuzzleLevel(value: 1), PuzzleLevel(value: 2),PuzzleLevel(value: 4)],
                [PuzzleLevel(value: 4), PuzzleLevel(value: 1), PuzzleLevel(value: 3), PuzzleLevel(value: 5),PuzzleLevel(value: 2)],
                [PuzzleLevel(value: 5), PuzzleLevel(value: 4), PuzzleLevel(value: 2), PuzzleLevel(value: 3),PuzzleLevel(value: 1)]
            ],
            top: [0,5,3,1,2,2,0],
            bottom: [0,1,2,4,2,4,0],
            left: [0,3,4,2,2,1,0],
            right: [0,3,1,2,2,4,0])
        
        let puzzle7 = Puzzle(
            puzzleLevel: [
                [PuzzleLevel(value: 3), PuzzleLevel(value: 1), PuzzleLevel(value: 2), PuzzleLevel(value: 4),PuzzleLevel(value: 5)],
                [PuzzleLevel(value: 1), PuzzleLevel(value: 2), PuzzleLevel(value: 3), PuzzleLevel(value: 5),PuzzleLevel(value: 4)],
                [PuzzleLevel(value: 4), PuzzleLevel(value: 3), PuzzleLevel(value: 5), PuzzleLevel(value: 2),PuzzleLevel(value: 1)],
                [PuzzleLevel(value: 5), PuzzleLevel(value: 4), PuzzleLevel(value: 1), PuzzleLevel(value: 3),PuzzleLevel(value: 1)],
                [PuzzleLevel(value: 2), PuzzleLevel(value: 5), PuzzleLevel(value: 4), PuzzleLevel(value: 1),PuzzleLevel(value: 3)]
            ],
            top: [0,0,5,3,0,0,0],
            bottom: [0,0,0,0,0,3,0],
            left: [0,0,0,0,0,0,0],
            right: [0,0,0,3,4,0,0])
        
        let puzzle8 = Puzzle(
            puzzleLevel: [
                [PuzzleLevel(value: 3), PuzzleLevel(value: 5), PuzzleLevel(value: 4), PuzzleLevel(value: 1),PuzzleLevel(value: 2)],
                [PuzzleLevel(value: 5), PuzzleLevel(value: 4), PuzzleLevel(value: 1), PuzzleLevel(value: 2),PuzzleLevel(value: 3)],
                [PuzzleLevel(value: 1), PuzzleLevel(value: 2), PuzzleLevel(value: 3), PuzzleLevel(value: 5),PuzzleLevel(value: 4)],
                [PuzzleLevel(value: 4), PuzzleLevel(value: 1), PuzzleLevel(value: 2), PuzzleLevel(value: 3),PuzzleLevel(value: 5)],
                [PuzzleLevel(value: 2), PuzzleLevel(value: 3), PuzzleLevel(value: 5), PuzzleLevel(value: 4),PuzzleLevel(value: 1)]

            ],
            top: [0,2,1,2,3,4,0],
            bottom: [0,3,3,1,2,2,0],
            left: [0,2,1,4,2,3,0],
            right: [0,3,3,2,1,3,0])
        
//        let puzzle9 = Puzzle(
//            puzzleLevel: [
//                [PuzzleLevel(value: 2), PuzzleLevel(value: 6), PuzzleLevel(value: 3), PuzzleLevel(value: 1),PuzzleLevel(value: 5),PuzzleLevel(value: 4)],
//                [PuzzleLevel(value: 1), PuzzleLevel(value: 2), PuzzleLevel(value: 4), PuzzleLevel(value: 5),PuzzleLevel(value: 6),PuzzleLevel(value: 3)],
//                [PuzzleLevel(value: 3), PuzzleLevel(value: 1), PuzzleLevel(value: 2), PuzzleLevel(value: 6),PuzzleLevel(value: 4),PuzzleLevel(value: 5)],
//                [PuzzleLevel(value: 6), PuzzleLevel(value: 5), PuzzleLevel(value: 1), PuzzleLevel(value: 4),PuzzleLevel(value: 3),PuzzleLevel(value: 2)],
//                [PuzzleLevel(value: 4), PuzzleLevel(value: 3), PuzzleLevel(value: 5), PuzzleLevel(value: 2),PuzzleLevel(value: 1),PuzzleLevel(value: 6)],
//                [PuzzleLevel(value: 5), PuzzleLevel(value: 4), PuzzleLevel(value: 6), PuzzleLevel(value: 3),PuzzleLevel(value: 2),PuzzleLevel(value: 1)]
//
//            ],
//            top: [0,3,1,4,3,2,3],
//            bottom: [0,2,3,1,3,4,2,0],
//            left: [0,2,5,2,1,3,2,0],
//            right: [0,3,3,2,1,3,0])
        
        level.puzzle.append(puzzle1)
        level.puzzle.append(puzzle2)
        level.puzzle.append(puzzle3)
        level.puzzle.append(puzzle4)
        level.puzzle.append(puzzle5)
        level.puzzle.append(puzzle6)
        level.puzzle.append(puzzle7)
        level.puzzle.append(puzzle8)
//        level.puzzle.append(puzzle9)
      
        
        
        
    }
}

struct Level {
    var puzzle: [Puzzle]
}

struct PuzzleLevel: Equatable {
    var value: Int
    var currentValue: String = ""
}

struct Puzzle {
    var puzzleLevel: [[PuzzleLevel]]
    var top: [Int]
    var bottom: [Int]
    var left: [Int]
    var right: [Int]
}
