//
//  GameView.swift
//  EnigmaterraWWDCREAL
//
//  Created by Aktiv on 2/25/24.
//

import SwiftUI

@available(iOS 17.0, *)
struct GameView: View {
    @State private var isShownAnswer: Bool = false
    @State private var restartGame: Bool = false
    @ObservedObject var provider = GameProvider()
    @State private var levelStatus: LevelStatus = .waiting
    @State private var levelIndex = 0
    var body: some View {
        VStack {
            Spacer()
            TabView(selection: $levelIndex) {
                ForEach(provider.level.puzzle.indices, id: \.self) { levelIndex in
                    ZStack {
                        // LEFT
                        VStack(spacing: 0) {
                            ForEach(provider.level.puzzle[levelIndex].left, id:\.self) { left in
                                ZStack {
                                    if left != 0 {
                                        Text("\(left)")
                                            .bold()
                                            .foregroundColor(.blue)
                                    }
                                    Rectangle()
                                        .stroke(lineWidth: 1)
                                }
                                .frame(width: 50, height: 50)
                            }
                        }
                        .offset(x: -100 + CGFloat(provider.level.puzzle[levelIndex].puzzleLevel.count - 3) * -25)
                        VStack(spacing: 0) {
                            // UP
                            HStack(spacing: 0) {
                                ForEach(provider.level.puzzle[levelIndex].top, id:\.self) { top in
                                    ZStack {
                                        if top != 0 {
                                            Text("\(top)")
                                                .bold()
                                                .foregroundColor(.blue)
                                        }
                                        Rectangle()
                                            .stroke(lineWidth: 1)
                                            
                                    }
                                    .frame(width: 50, height: 50)
                                }
                            }
                            // GAME
                            VStack(spacing: 0) {
                                ForEach(provider.level.puzzle[levelIndex].puzzleLevel.indices, id: \.self) { row in
                                    HStack(spacing: 0) {
                                        ForEach(provider.level.puzzle[levelIndex].puzzleLevel.indices, id: \.self) { col in
                                            ZStack {

                                                GameInputView(levelPuzzle: .constant(provider.level.puzzle[levelIndex].puzzleLevel[row][col]), isShownAnswer: $isShownAnswer, restartGame: $restartGame, levelStatus: $levelStatus)
                                            }
                                            
                                        }
                                        .frame(width: 50, height: 50)
                                    }
                                }
                                .frame(width: 50, height: 50)
                            }
                            //DOWN
                            HStack(spacing: 0) {
                                ForEach(provider.level.puzzle[levelIndex].bottom, id:\.self) { bottom in
                                    ZStack {
                                        if bottom != 0 {
                                            Text("\(bottom)")
                                                .bold()
                                                .foregroundColor(.blue)
                                        }
                                        Rectangle()
                                            .stroke(lineWidth: 1)
                                            
                                    }
                                    .frame(width: 50, height: 50)
                                }
                            }
                        }
                        // RIGHT
                        VStack(spacing: 0) {
                            ForEach(provider.level.puzzle[levelIndex].right, id:\.self) { right in
                                ZStack {
                                    if right != 0 {
                                        Text("\(right)")
                                            .bold()
                                            .foregroundColor(.blue)
                                    }
                                    Rectangle()
                                        .stroke(lineWidth: 1)
                                        
                                }
                                .frame(width: 50, height: 50)
                            }
                        }
                        .offset(x: 100 + CGFloat(provider.level.puzzle[levelIndex].puzzleLevel.count - 3) * 25)
                    }
                    .tag(levelIndex)
                    if levelIndex == provider.level.puzzle.count - 1 {
                        CongratulationsView()
                            .tag(provider.level.puzzle.count)
                    }
                }
            }
            .tabViewStyle(.page)
            Spacer()
            Button {
                isShownAnswer = true
            } label: {
                Text("Show the Answer. \(levelStatus.rawValue)")
            }
            .padding(.bottom, 32)
            .onChange(of: levelStatus, {
                if case .next = levelStatus {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                        if levelIndex < provider.level.puzzle.count {
                            levelIndex += 1
                            levelStatus = .waiting
                            isShownAnswer = false
                        }
                        
                    }
                }
            })
        }
        .onAppear {
            provider.generateLevel()
        }
    }
}

