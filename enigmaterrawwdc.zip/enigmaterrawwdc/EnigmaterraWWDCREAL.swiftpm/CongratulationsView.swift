//
//  CongratulationsView.swift
//  EnigmaterraWWDCREAL
//
//  Created by Aktiv on 2/25/24.
//

import SwiftUI

struct CongratulationsView: View {
    var body: some View {
        Text("Congratulations .)")
            .font(.largeTitle)
            .bold()
    }
}

#Preview {
    CongratulationsView()
}
