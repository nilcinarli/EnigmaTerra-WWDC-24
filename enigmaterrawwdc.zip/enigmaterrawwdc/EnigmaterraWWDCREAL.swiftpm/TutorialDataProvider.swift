//
//  TutorialDataProvider.swift
//  EnigmaterraWWDCREAL
//
//  Created by Aktiv on 2/25/24.
//

import Foundation

final class TutorialDataProvider {
    
    func getFirstTutorialViewArticle() -> [Article] {
        let article: [Article] = [
            .title("How to Play, Page 1"),
            .logo("articleImage"),
            .image("tutorial1"),
            .image("tutorial2"),
            .image("tutorial3"),
            .image("tutorial4"),
            .image("tutorial5")
        ]
        return article
    }
    
    func getSecondTutorialViewArticle() -> [Article] {
        let article: [Article] = [
            .title("How to Play, Page 2"),
            .logo("articleImage"),
            .text("To place skyscraper on the board, first select the square you want to answer, then type the height of the skyscraper from your keyboard"),
            .image("tutorial6"),
            .image("tutorial7"),
            .image("tutorial8"),
            .image("tutorial9")
            
        ]
        return article
    }
    
    func getThirdTutorialViewArticle() -> [Article] {
        let article: [Article] = [
            .title("How to Play, Page 3"),
            .logo("articleImage"),
            .image("tutorial10"),
            .image("tutorial11"),
            .image("tutorial12"),
            .image("tutorial13")
        ]
        return article
    }
}
